#include "Circle.h"

// Box2D uses meters for simulation, so we need to set how many pixels representing one meter
// We prefer a 2^n value (e.g. 1,2,4,8,16,32,64 etc) because of reasons
// Why? Refer to Computer Graphics
static const float PIXEL_PER_METER = 32.0f;

Circle::Circle(b2World &world,
               float radius,
               sf::Vector2f position,
               float rotation,
               bool isDynamic)
{
    rect_ = sf::CircleShape(radius);
    rect_.setOrigin(sf::Vector2f(radius/ 2, radius/ 2));
    rect_.setFillColor(sf::Color(255, 255, 255, 255));
    rect_.setOutlineThickness(1);
    rect_.setOutlineColor(sf::Color::Black);

    bodyDef_.position = b2Vec2(position.x / PIXEL_PER_METER, position.y / PIXEL_PER_METER);

    if (isDynamic)
    {
        bodyDef_.type = b2_dynamicBody;
    }
    else
    {
        bodyDef_.type = b2_staticBody;
    }

    bodyShape_.m_p.Set((radius/2) / PIXEL_PER_METER, (radius/2) / PIXEL_PER_METER);

    bodyFixtureDef_.shape = &bodyShape_;
    bodyFixtureDef_.density = 0.3f;
    bodyFixtureDef_.friction = 0.5f;

    body_ = world.CreateBody(&bodyDef_);
    body_->CreateFixture(&bodyFixtureDef_);
}

void Circle::setFillColor(sf::Color col)
{
    rect_.setFillColor(col);
}

void Circle::setOutlineThickness(float thickness)
{
    rect_.setOutlineThickness(thickness);
}

void Circle::setOutlineColor(sf::Color col)
{
    rect_.setOutlineColor(col);
}

void Circle::update()
{
    // Box2D uses radians for rotation, SFML uses degree
    rect_.setRotation(body_->GetAngle() * 180 / b2_pi);
    rect_.setPosition(body_->GetPosition().x * PIXEL_PER_METER, body_->GetPosition().y * PIXEL_PER_METER);
}

sf::Shape &Circle::getShape()
{
    return rect_;
}