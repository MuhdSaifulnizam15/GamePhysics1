#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <Box2D/Box2D.h>
#include "Circle.h"
#include "MyRectangle.h"
#include <iostream>
#include <sstream> // for ostringstream
#include <vector>

sf::Font loadFont(const std::string &fontFilename = "resources/04b03.ttf")
{
	sf::Font myFont;
	if (!myFont.loadFromFile(fontFilename))
	{
		std::cout << "Can not load font from " << fontFilename << std::endl;
		exit(1);
	}
	return myFont;
}

int main()
{
	// Timer for fixed update
	float fixedTimeStep = 0.02f; // 50 times per second
	sf::Clock fixedUpdateClock;
	float timeElapsedSinceLastFrame = 0;

	// Window creation
	int windowSizeX = 800, windowSizeY = 600;
	int windowBorderSize = 16;
	sf::RenderWindow window(sf::VideoMode(windowSizeX, windowSizeY), "SFML with Box2D");

	// Set vSync to true (and as a result, we have a cap of 60FPS)
	window.setVerticalSyncEnabled(true);
	window.setActive();

	// Create gravity and world, then assign gravity to world
	b2Vec2 gravity(0.f, 9.81f);
	//b2Vec2 gravity(0.f, 0.f);
	b2World world(gravity);

	// Border creation
	sf::Vector2f horizontalBorderSize(windowSizeX, windowBorderSize);
	sf::Vector2f verticalBorderSize(windowBorderSize, windowSizeY - windowBorderSize * 2);
	sf::Vector2f topBorderPos(windowSizeX / 2, windowBorderSize / 2);
	sf::Vector2f bottomBorderPos(windowSizeX / 2, windowSizeY - windowBorderSize / 2);
	sf::Vector2f leftBorderPos(windowBorderSize / 2, windowSizeY / 2);
	sf::Vector2f rightBorderPos(windowSizeX - windowBorderSize / 2, windowSizeY / 2);
	MyRectangle topBorder(world, horizontalBorderSize, topBorderPos, 0.0, false);
	topBorder.setOutlineThickness(-1);
	topBorder.setOutlineColor(sf::Color::Black);
	topBorder.setFillColor(sf::Color(100, 100, 100));
	MyRectangle bottomBorder(world, horizontalBorderSize, bottomBorderPos, 0.0, false);
	bottomBorder.setOutlineThickness(-1);
	bottomBorder.setOutlineColor(sf::Color::Black);
	bottomBorder.setFillColor(sf::Color(100, 100, 100));
	MyRectangle leftBorder(world, verticalBorderSize, leftBorderPos, 0.0, false);
	leftBorder.setOutlineThickness(-1);
	leftBorder.setOutlineColor(sf::Color::Black);
	leftBorder.setFillColor(sf::Color(100, 100, 100));
	MyRectangle rightBorder(world, verticalBorderSize, rightBorderPos, 0.0, false);
	rightBorder.setOutlineThickness(-1);
	rightBorder.setOutlineColor(sf::Color::Black);
	rightBorder.setFillColor(sf::Color(100, 100, 100));

	// A vector/list of boxes
	std::vector<Circle> circleList;
	sf::Vector2f dynamicBoxSize(32, 32);

	//Loading music
	//SFML can only play .wav/.ogg but not .mp3 file
	// sf::Music music;
	// if(!music.openFromFile("music.ogg"))
	// 	return 	EXIT_FAILURE;

	// music.play();

	// Text creation
	sf::Font font = loadFont();
	sf::Text text;
	text.setFont(font);
	text.setCharacterSize(16);
	text.setPosition(3, -3);
	text.setColor(sf::Color::White);

	// A buffer to check whether left mouse button has been clicked before or not
	bool leftMousePressed = false;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
			;
		{
			// This is input handling via poll event
			// Do not use this for game input
			// Why? Delay issues
			// READ SFML DOCUMENTATION!
			if (event.type == sf::Event::Closed)
				window.close();
		}

		// This is input handling without poll event
		// READ SFML DOCUMENTATION!
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
		{
			if (!leftMousePressed)
			{
				sf::Vector2f pos = sf::Vector2f(sf::Mouse::getPosition(window));
				Circle r(world, 16.0f, pos);
				r.setOutlineThickness(1);
				r.setOutlineColor(sf::Color::Black);
				r.setFillColor(sf::Color(100, 100, 200));
				circleList.push_back(r);
				leftMousePressed = true;
			}
		}
		else
		{
			leftMousePressed = false;
		}

		// We get the time elapsed since last frame and add it to timeElapsedSinceLastFrame
		timeElapsedSinceLastFrame += fixedUpdateClock.restart().asSeconds();

		// If sufficient time has elapsed, we update the physics
		if (timeElapsedSinceLastFrame >= fixedTimeStep)
		{
			// Step is used to update physics position/rotation
			world.Step(fixedTimeStep, //update frequency
					   8,			  //velocityIterations
					   3			  //positionIterations
			);

			// Update the objects that uses physics
			topBorder.update();
			bottomBorder.update();
			leftBorder.update();
			rightBorder.update();

			for (int i = 0; i < circleList.size(); i++)
			{
				circleList[i].update();
			}

			// timeElapsedSinceLastFrame can be higher than fixedTimeStep,
			// so we deduct timeElapsedSinceLastFrame with fixedTimeStep
			timeElapsedSinceLastFrame -= fixedTimeStep;
		}

		// Rendering
		window.clear(sf::Color(100, 149, 237)); // CORNFLOWER BLUE!

		// Render all objects
		window.draw(topBorder.getShape());
		window.draw(bottomBorder.getShape());
		window.draw(leftBorder.getShape());
		window.draw(rightBorder.getShape());

		for (int i = 0; i < circleList.size(); i++)
		{	
			window.draw(circleList[i].getShape());
		}

		std::ostringstream circleListStream;
		circleListStream << circleList.size();
		text.setString("Number of circle: " + circleListStream.str());
		window.draw(text);
		window.display();
	}

	return 0;
}
