#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

class Circle
{
private:
    sf::CircleShape rect_;
    b2Body *body_;
    b2BodyDef bodyDef_;
    b2CircleShape bodyShape_;
    b2FixtureDef bodyFixtureDef_;

public:
    Circle(b2World &world,
           float radius,
           sf::Vector2f position,
           float rotation = 0,
           bool isDynamic = true);
    void setFillColor(sf::Color col);
    void setOutlineThickness(float thickness);
    void setOutlineColor(sf::Color col);
    void update();
    sf::Shape &getShape();
};
